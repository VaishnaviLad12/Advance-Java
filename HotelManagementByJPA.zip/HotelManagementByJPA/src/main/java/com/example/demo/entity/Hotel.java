package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class Hotel {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	private String name;
	private String HotelType;
	private String Quality;
	
	
	@Override
	public String toString() {
		return "Hotel [id=" + id + ", name=" + name + ", HotelType=" + HotelType + ", Quality=" + Quality + "]";
	}
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHotelType() {
		return HotelType;
	}
	public void setHotelType(String hotelType) {
		HotelType = hotelType;
	}
	public String getQuality() {
		return Quality;
	}
	public void setQuality(String quality) {
		Quality = quality;
	}


	public Hotel(long id, String name, String hotelType, String quality) {
		super();
		this.id = id;
		this.name = name;
		HotelType = hotelType;
		Quality = quality;
	}
	
	
	

}
