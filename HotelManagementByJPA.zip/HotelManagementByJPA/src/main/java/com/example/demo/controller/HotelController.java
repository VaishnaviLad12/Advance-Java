package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Hotel;
import com.example.demo.service.HotelService;

@RestController
@RequestMapping("/Hotels")
public class HotelController {
	
	@Autowired
	private HotelService hotelService;
	
	public List<Hotel> getAllHotel(){
		return hotelService.getAllHotel();
	}
	public Hotel addHotel(@RequestBody Hotel hotel) {
		return hotelService.saveHotel(hotel);
	}
	public ResponseEntity<Hotel>updateHotels(@PathVariable Long id, @RequestBody Hotel updateHotel){
		Hotel existingHotel=hotelService.getHotelById(id);
		
		if (existingHotel!=null) {
			existingHotel.setName(updateHotel.getName());
			existingHotel.setHotelType(updateHotel.getHotelType());
			existingHotel.setQuality(updateHotel.getQuality());
			
			Hotel savedHotel=hotelService.updateHotel(existingHotel);
			return ResponseEntity.ok(savedHotel);
		}else {
			return ResponseEntity.notFound().build();
		}
	}
	

	public ResponseEntity<Void> deletehotelbyId(@PathVariable Long id) {
		boolean isDeleted = hotelService.deleteHotelById(id);
		if (isDeleted) {
			return ResponseEntity.noContent().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}

}
